// Obtener el parámetro 'id' de la URL
const urlParams = new URLSearchParams(window.location.search);
const cursoId = urlParams.get('id');

// Realizar una petición a la API para obtener los detalles del curso con el 'id' proporcionado
fetch('https://potrerocursos-default-rtdb.firebaseio.com/cursos/' + cursoId + '.json')
  .then(response => response.json())
  .then(curso => {
    const descripcionContainer = document.getElementById('descripcion-container');

    // Crear elementos HTML para mostrar los detalles del curso
    const nombreTitulo = document.createElement('h2');
    nombreTitulo.textContent = 'Nombre del Curso';
    const nombre = document.createElement('p');
    nombre.textContent = curso.titulo;

    const presentacionTitulo = document.createElement('h2');
    presentacionTitulo.textContent = 'Presentación';
    const presentacion = document.createElement('p');
    presentacion.textContent = curso.descripcion;

    const imagen = document.createElement('img');
    imagen.src = curso.imagen;
    imagen.style.maxWidth = '400px'; // Establecer un ancho máximo para la imagen


    const requisitosTitulo = document.createElement('h2');
    requisitosTitulo.textContent = 'Requisitos';
    const requisitos = document.createElement('p');
    requisitos.textContent = curso.requisitos;

    const valorTitulo = document.createElement('h2');
    valorTitulo.textContent = 'Valor';
    const valor = document.createElement('p');
    valor.textContent = curso.precio;

    descripcionContainer.appendChild(nombreTitulo);
    descripcionContainer.appendChild(nombre);
    descripcionContainer.appendChild(presentacionTitulo);
    descripcionContainer.appendChild(presentacion);
    descripcionContainer.appendChild(imagen);
    descripcionContainer.appendChild(requisitosTitulo);
    descripcionContainer.appendChild(requisitos);
    descripcionContainer.appendChild(valorTitulo);
    descripcionContainer.appendChild(valor);
    
  }).catch(error => console.log(error));

  // Limpia el contenido existente antes de cargar los datos desde Firebase
  document.addEventListener('DOMContentLoaded', getData);
  
  // Establece un intervalo para actualizar los datos cada 5 segundos
  setInterval(getData, 5000);