// Obtener el ID del registro desde el almacenamiento local
let registroId = localStorage.getItem("registroId");

console.log(registroId);

if (registroId) {
  // Obtener los datos del registro desde la API
  let registroUrl = "https://registropotrero-default-rtdb.firebaseio.com/registro/" + registroId + ".json";
  fetch(registroUrl)
    .then(function(response) {
      return response.json();
    })
    .then(function(data) {
      // Obtener el nombre y apellido del registro
      let nombreApellido = data.nombreyapellido;

      // Mostrar el mensaje de bienvenida
      document.getElementById("bienvenido").textContent = "Bienvenido " + nombreApellido;

      // Obtener el curso del registro
      let curso = data.curso;

      // Obtener los datos del curso desde la API
      let cursosUrl = "https://potrerocursos-default-rtdb.firebaseio.com/cursos.json";
      fetch(cursosUrl)
        .then(function(response) {
          return response.json();
        })
        .then(function(cursosData) {
          // Buscar el curso que coincida con el nombre del curso del registro
          for (let key in cursosData) {
            if (cursosData.hasOwnProperty(key) && cursosData[key].titulo === curso) {
              let cursoEncontrado = cursosData[key];
              // Mostrar los datos del curso
              mostrarDatosCurso(cursoEncontrado);
              break;
            }
          }
        })
        .catch(function(error) {
          console.error(error);
        });
    })
    .catch(function(error) {
      console.error(error);
    });
} else {
  // Si no se encuentra el ID del registro en el almacenamiento local, redirigir a login.html
  window.location.href = "login.html";
}

function mostrarDatosCurso(curso) {
  let cursoContainer = document.getElementById("cursoInfo");
  cursoContainer.innerHTML = `
    <h2>${curso.titulo}</h2>
    <img src="${curso.imagen}" alt="${curso.titulo}">
    <p><strong>Presentación:</strong> ${curso.descripcion}</p>
    <p><strong>Requisitos:</strong> ${curso.requisitos}</p>`;
  document.appendChild(cursoContainer);
}
// Obtener el botón de perfil
let perfilButton = document.getElementById("perfilButton");

// Agregar el evento click al botón de perfil
perfilButton.addEventListener("click", function() {
  // Obtener el ID del registro desde el almacenamiento local
  let registroId = localStorage.getItem("registroId");

  // Generar la URL de profile.html con el ID del registro
  let profileUrl = "profile.html?id=" + registroId;

  // Abrir "profile.html" en una ventana flotante
  window.open(profileUrl, "Perfil", "width=600,height=400");
});

  // Agregar evento click al botón de logout
  let logoutButton = document.getElementById("logoutButton");
  logoutButton.addEventListener("click", function() {
    // Limpiar el almacenamiento local y redirigir a login.html
    localStorage.removeItem("registroId");
    window.location.href = "login.html";
  });

