// cursos.js

// Función para obtener los datos de Firebase y generar las cards
function getData() {
    fetch('https://potrerocursos-default-rtdb.firebaseio.com/cursos.json')
      .then(response => response.json())
      .then(data => {
        const cardDeck = document.querySelector('.container .row'); // Selecciona el elemento contenedor de las tarjetas
  
        // Limpia el contenido existente antes de agregar las nuevas tarjetas
        cardDeck.innerText = '';
  
        // Itera sobre los datos obtenidos y genera las tarjetas
        for (let key in data) {
          const curso = data[key];
  
          const card = document.createElement('div');
          card.classList.add('col-md-3', 'col-sm-6', 'mb-4');
  
          const cardBlock = document.createElement('div');
          cardBlock.classList.add('card', 'card-block');
  
          const title = document.createElement('h4');
          title.classList.add('card-title', 'text-right');
          title.innerHTML = curso.titulo;
  
          const image = document.createElement('img');
          image.classList.add('img-fluid');
          image.src = curso.imagen;
          image.alt = 'Course Image';
  
          const courseTitle = document.createElement('h5');
          courseTitle.classList.add('card-title', 'mt-3', 'mb-3');
          courseTitle.textContent = 'Duracion: ' + curso.duracion;
  
          const   price = document.createElement('p');
          price.classList.add('card-text');
          price.textContent = `Valor: ${curso.precio}` ;

          const botonDetalle = document.createElement('button'); // Crear el botón de detalle
              botonDetalle.classList.add('btn', 'btn-primary');
              botonDetalle.textContent = 'Detalle';
              // Agregar el evento de clic al botón para redirigir a otra página
              botonDetalle.addEventListener('click', function() {
                window.location.href = 'details.html?id=' + key}); // Cambia 'otra_pagina.html' por la ruta de tu página y 'id' por el parámetro necesario para identificar el objeto en la página de descripción

          
          cardBlock.appendChild(title);      
          cardBlock.appendChild(title);
          cardBlock.appendChild(image);
          cardBlock.appendChild(courseTitle);
          cardBlock.appendChild(price);
          card.appendChild(cardBlock);
          cardBlock.appendChild(botonDetalle);
          cardDeck.appendChild(card);
        }
      })
      .catch(error => console.log(error));
  }
  
  // Limpia el contenido existente antes de cargar los datos desde Firebase
  document.addEventListener('DOMContentLoaded', getData);
  
  // Establece un intervalo para actualizar los datos cada 5 segundos
  setInterval(getData, 5000);
  
