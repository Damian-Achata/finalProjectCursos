document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Evitar que se envíe el formulario automáticamente

    let dniInput = document.getElementById("dni").value;
    let contraseniaInput = document.getElementById("password").value;
    let url = "https://registropotrero-default-rtdb.firebaseio.com/registro.json";

    // Realizar la petición GET a la API para obtener los registros
    fetch(url)
      .then(function(response) {
        return response.json();
      })
      .then(function(data) {
        let registroEncontrado = false;
        let registroId;

        // Buscar el registro que coincida con el DNI y la contraseña ingresados
        for (let key in data) {
          if (data.hasOwnProperty(key) && data[key].dni === dniInput && data[key].password === contraseniaInput) {
            registroEncontrado = true;
            registroId = key;
            break;
          }
        }

        if (registroEncontrado) {
          // Guardar el ID del registro en el almacenamiento local
          localStorage.setItem("registroId", registroId);

          // Redirigir a alumnoscookies.html
          window.location.href = "alumnos.html";
        } else {
          alert("Credenciales inválidas. Por favor, intenta nuevamente.");
        }
      })
      .catch(function(error) {
        alert("Ha ocurrido un error. Por favor, intenta nuevamente.");
        console.error(error);
      });
  });