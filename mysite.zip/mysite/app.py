from flask import Flask, render_template


app = Flask(__name__, static_folder='static');

@app.route('/')
def home():
    return render_template("home.html")


@app.route('/about')
def about():
    return render_template("about.html")

@app.route('/contact')
def contact():
    return render_template("contact.html")

@app.route('/courses')
def courses():
    return render_template("courses.html")

@app.route('/team')
def team():
    return render_template("team.html")

@app.route('/404')
def error_404():
    return render_template("404.html")

@app.route('/testimonial')
def testimonial():
    return render_template("testimonial.html")

@app.route('/details.html')
def details():
    return render_template("details.html")

@app.route('/login.html')
def login():
    return render_template("login.html")

@app.route('/registro.html')
def registro():
    return render_template("registro.html")

@app.route('/alumnos.html')
def alumnos():
    return render_template("alumnos.html")

@app.route('/profile.html')
def profile():
    return render_template("profile.html")


if __name__ == '__main__':
    app.run(debug=True)